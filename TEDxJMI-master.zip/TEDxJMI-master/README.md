![TEDxJMI logo](res/images/logos/light.png)

[![Website status](https://img.shields.io/website-up-down-green-red/https/tedxjmi.netlify.com.svg?label=Website%20status&style=for-the-badge)](https://tedxjmi.netlify.com)

> Event website for TEDxJMI 2017

## Screenshot

![screenshot-2018-1-16](https://user-images.githubusercontent.com/11466676/34989795-e0b351e2-fae9-11e7-95ea-d42b85d4b6cd.jpg)

## License

This project is licensed under the terms of the [MIT license](LICENSE).
